const Discord = require('discord.js')

// Cliente

const Client = new Discord.Client({intents: 3276799});

const embed = {
    title: 'Soporte',
    description: '¡Este es el sistema de soporte de **Aquatic Network**!',
    color: 0x5865F2,
    fields: [
        {
			name: '\u200b',
			value: 'Puedes contactar con el equipo de staff del servidor',
			inline: false,
		},
		{
			name: '\u200b',
			value: '**Cualquier persona que abra ticket pidiendo la IP del servidor será sancionada**',
		},
		{
			name: '\u200b',
			value: '**También se sancionarán a las personas que abran tickets preguntando por postulaciones, ya que se realizan por mapa **',
			inline: false,
		},
	],
};

const menu = new Discord.ActionRowBuilder().addComponents(
    new Discord.StringSelectMenuBuilder()
         .setPlaceholder('Abre un ticket')
         .setMaxValues(1)
         .setMinValues(1)
         .setCustomId('ticket-create')
         .setOptions([{
        label: 'Soporte',
        emoji: '👋',
        description: 'Abre un ticket de soporte general',
        value: 'Soporte'
    }, {
        label: 'Reporte',
        emoji: '⚠️',
        description: 'Reporta algún bug, usuario, o staff',
        value: 'reporte'
    }, {
        label: 'Compra',
        emoji: '💵',
        description: 'Ticket para duda o soporte para realizar una compra',
        value: 'Compra'
    }, {
        label: 'Solicitud',
        emoji: '🖥',
        description: 'Abre un ticket para postularte como media o solicitar algo',
        value: 'solicitud'
    },

])
);

Client.on('ready', async (client) => {
    const ticketPanelChannelId = "1066137168566833152"// id del canal
    client.channels.fetch(ticketPanelChannelId)
    .then(channel => channel.send({embeds: [embed], components: [menu]}))
});

Client.on('ready', async ( client ) => {
    console.log('Estoy Listo!')

   Client.user.setPresence({
    activities: [{ name: `Aquatic Network`, type: Discord.ActivityType.Playing }],
    status: 'online',
    });
});

/// Evento Interaction Create

Client.on("interactionCreate", async (interaction) => {
    if(interaction.isChatInputCommand()) return;
    
    try {
        const execute = require(`./interactions/${interaction.customId}`);
        execute(interaction);
    }  catch (error) {
        console.log(error)
    }

});

// Registro
Client.login("MTE4MTc1ODQzMzkxODE4OTU2OQ.GD7ZfD.oXW-pUTUeOeiY88iQ1dwiH-XxDhVioS-4dlQdk")